OJA AI FIXED ATTACHMENT + AUDIO + IMAGE GENERATION

1. Replace your current OJA AI HTML file with oja-ai.html (or rename it to the filename your project uses).
2. Copy the functions folder into the Firebase project root.
3. Keep your existing config.js, but make sure it contains your valid GROQ_API_KEY.
4. In functions/.env, add your Hugging Face token:
   HF_TOKEN=your_hugging_face_token
   Do NOT commit this token to source control.
5. From the Firebase project root, install/deploy the functions:
   cd functions
   npm install
   cd ..
   firebase deploy --only functions
6. The generated image endpoint is the us-central1 generateImage function.

What was fixed:
- Image attachments are now sent to Groq's vision model as real image URLs.
- Audio attachments are transcribed with Groq Whisper before the AI response.
- Recorded voice messages are transcribed and then sent to OJA AI.
- Uploaded audio is classified as audio instead of a generic file.
- AI messages include extracted document/file text when available.
- Image generation now has a Firebase Cloud Function backend using Hugging Face Inference Providers.
- Upload/processing failures are surfaced instead of silently pretending the AI received the file.

IMPORTANT SECURITY NOTE:
Your existing project has a Groq API key in client-side config.js. Rotate/revoke that key and move AI API calls behind a backend when you are ready. The fixed frontend keeps the current architecture so the features can be tested without a full rewrite.
